package Test1.Q4;

public class Test {

    public static void main(String[] args) {
        Children ob = new Children();
        ob.cook();
        ob.eat();
        ob.walk();

    }
}
