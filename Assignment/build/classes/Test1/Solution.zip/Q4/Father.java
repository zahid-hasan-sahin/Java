package Test1.Q4;

public interface Father extends Person {

    void eat();
}
