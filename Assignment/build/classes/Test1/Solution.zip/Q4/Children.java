package Test1.Q4;

public class Children implements Father, Mother {

    @Override
    public void eat() {
        System.out.println("eating");
    }

    @Override
    public void walk() {
        System.out.println("walking");
    }

    @Override
    public void cook() {
        System.out.println("cooking");
    }

}
