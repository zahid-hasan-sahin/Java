package Test1.Q4;

public interface Mother {

    void cook();
}
