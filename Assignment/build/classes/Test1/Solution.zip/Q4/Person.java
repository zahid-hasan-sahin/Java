
package Test1.Q4;

public interface Person {
    void walk();
}
