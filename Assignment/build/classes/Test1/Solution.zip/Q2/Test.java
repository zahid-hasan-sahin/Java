package Test1.Q2;

public class Test {

    public static void main(String[] args) {
        Person.setCity("city1");
        Person ob = new Student();
        ob.setName("name1");
        ob.setAge(22);
        
        ob.work();
        System.out.println(ob);
        System.out.println(ob.getCity());
        

    }

}
