package Test1.Q2;

public class Person {

    private String name;
    int age;
    static String city;

    public void work(){
        System.out.println("Doing some Job");
    }
    
    public static void setCity(String c) {
        city = c;
    }

    public static String getCity() {
        return city;
    }

    public Person() {
    }

    public Person(String name) {
        this.name = name;

    }

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", age=" + age + '}';
    }
    
    

}
