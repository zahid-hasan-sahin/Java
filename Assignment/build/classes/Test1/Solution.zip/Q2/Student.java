package Test1.Q2;

public class Student extends Person {

    private String university;

    @Override
    public void work() {
        System.out.println("Doing Home work");
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    Student() {

    }

    public Student(String university) {
        this.university = university;
    }

    public Student(String university, String name) {
        super(name);
        this.university = university;
    }

    public Student(String university, String name, int age) {
        super(name, age);
        this.university = university;
    }

}
