package Test1.Q1;

public class Test {

    public static void main(String[] args) {
        Student.setUniversity("university1");

        Student stu1 = new Student();
        stu1.setName("A");
        stu1.setAge(22);
        stu1.setCity("city1");

        System.out.println(stu1);
        System.out.println(stu1.getUniversity());

    }
}
